import { createClient } from '@supabase/supabase-js';

export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceRole) throw new Error('El acceso de servidor a Supabase no está configurado.');
  return createClient(url, serviceRole, { auth: { autoRefreshToken: false, persistSession: false } });
}
